ThrottleStop 9.4
2021 August 17

New Features
- fixed the FIVR - Disable and Lock MMIO feature for 11th Gen CPUs. 
- added separate reporting of the MSR and MMIO power limits. 
- added feature to disable all C states higher than C1. 
- added access to the Ring Down Bin setting.
- enabled Limit Reasons for Skylake X.
- fixed power plan list for languages other than English.
- changed system monitoring timers being used.


Kevin Glynn
throttlestop@shaw.ca
